
-- --------------------------------------------------------

--
-- Estrutura para vista `policiais`
--
DROP TABLE IF EXISTS `policiais`;

DROP VIEW IF EXISTS `policiais`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `policiais`  AS  select `f`.`id` AS `id`,`f`.`NOME_PO` AS `nome`,`f`.`NOMEGUERRA_PO` AS `nome_guerra`,`f`.`CPF_PO` AS `cpf`,`g`.`posto_graduacao` AS `graduacao`,`g`.`posto_precedencia` AS `precedencia`,`f`.`MATRICULA_PO` AS `matricula`,`f`.`rg_pm` AS `rg`,`u`.`codigo` AS `opm`,`u`.`nome_pais` AS `nome_pais`,`f`.`DATAINCLUSAO_PO` AS `dt_inc`,`f`.`NUMERO_PO` AS `numero_praca` from ((`dp_rh`.`funcionarios` `f` join `dp_rh`.`graduacoes` `g` on(`g`.`id` = `f`.`graduacao_id`)) join `dp_rh`.`unidades` `u` on(`u`.`id` = `f`.`unidade_id`)) ;
