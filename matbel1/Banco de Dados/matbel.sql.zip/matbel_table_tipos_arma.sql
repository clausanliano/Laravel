
-- --------------------------------------------------------

--
-- Estrutura da tabela `tipos_arma`
--

DROP TABLE IF EXISTS `tipos_arma`;
CREATE TABLE `tipos_arma` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tipos_arma`
--

INSERT INTO `tipos_arma` (`id`, `nome`, `created_at`, `updated_at`, `deleted_at`) VALUES
(3, 'Pistola', '2020-05-04 04:49:52', '2020-05-04 04:49:52', NULL),
(4, 'Revólver', '2020-06-11 22:36:16', '2020-06-11 22:36:16', NULL),
(5, 'Fuzil', '2020-06-11 22:36:26', '2020-06-11 22:36:40', NULL),
(6, 'Carabina', '2020-06-11 22:36:49', '2020-06-11 22:36:49', NULL),
(7, 'Espingarda', '2020-06-11 22:36:59', '2020-06-11 22:36:59', NULL);
