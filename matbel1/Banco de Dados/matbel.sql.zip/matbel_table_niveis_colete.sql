
-- --------------------------------------------------------

--
-- Estrutura da tabela `niveis_colete`
--

DROP TABLE IF EXISTS `niveis_colete`;
CREATE TABLE `niveis_colete` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `niveis_colete`
--

INSERT INTO `niveis_colete` (`id`, `nome`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'II', NULL, NULL, NULL),
(2, 'II-A', NULL, NULL, NULL),
(3, 'III', NULL, NULL, NULL),
(4, 'III-A', NULL, NULL, NULL),
(5, 'IV', NULL, NULL, NULL),
(6, 'IV-A', NULL, '2020-07-04 01:09:23', NULL),
(8, '-', NULL, NULL, NULL);
