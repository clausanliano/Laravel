
-- --------------------------------------------------------

--
-- Estrutura para vista `opms`
--
DROP TABLE IF EXISTS `opms`;

DROP VIEW IF EXISTS `opms`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `opms`  AS  select `u`.`id` AS `id`,`u`.`codigo` AS `nome`,`u`.`tipo` AS `tipo`,`u`.`unidade_id` AS `unidade_id`,`u`.`pais` AS `pais`,`u`.`nome_pais` AS `nome_pais` from `dp_rh`.`unidades` `u` ;
