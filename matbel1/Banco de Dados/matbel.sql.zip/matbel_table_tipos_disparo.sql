
-- --------------------------------------------------------

--
-- Estrutura da tabela `tipos_disparo`
--

DROP TABLE IF EXISTS `tipos_disparo`;
CREATE TABLE `tipos_disparo` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tipos_disparo`
--

INSERT INTO `tipos_disparo` (`id`, `nome`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Acidental', '2020-04-29 00:43:16', '2020-04-29 00:43:16', NULL),
(2, 'Teste', '2020-04-29 00:43:32', '2020-04-29 00:43:32', NULL),
(3, 'Em Serviço', '2020-04-29 00:43:53', '2020-04-29 00:43:53', NULL),
(4, 'Homenagem', '2020-06-11 22:49:59', '2020-06-11 22:50:56', NULL);
