
-- --------------------------------------------------------

--
-- Estrutura da tabela `disparos`
--

DROP TABLE IF EXISTS `disparos`;
CREATE TABLE `disparos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `data_hora` date NOT NULL,
  `quantidade` int(11) NOT NULL,
  `observacao` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opm_id` bigint(20) UNSIGNED NOT NULL,
  `policial_id` bigint(20) UNSIGNED NOT NULL,
  `arma_id` bigint(20) UNSIGNED NOT NULL,
  `tipo_municao_id` bigint(20) UNSIGNED NOT NULL,
  `tipo_disparo_id` bigint(20) UNSIGNED NOT NULL,
  `localizacao_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `disparos`
--

INSERT INTO `disparos` (`id`, `data_hora`, `quantidade`, `observacao`, `opm_id`, `policial_id`, `arma_id`, `tipo_municao_id`, `tipo_disparo_id`, `localizacao_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(5, '2020-07-02', 3, NULL, 14, 11729, 5, 3, 2, NULL, '2020-06-11 19:20:10', '2020-07-04 01:33:27', NULL),
(6, '2020-06-11', 2, NULL, 12, 4567, 5, 3, 3, NULL, '2020-06-11 22:52:02', '2020-06-11 22:52:24', NULL),
(7, '2020-06-29', 5, NULL, 13, 425, 10, 3, 3, NULL, '2020-06-29 16:23:49', '2020-06-29 16:23:49', NULL),
(8, '2020-06-29', 5, NULL, 13, 6, 10, 1, 2, NULL, '2020-06-29 17:39:17', '2020-06-29 17:39:17', NULL),
(9, '2020-06-18', 6, NULL, 12, 3, 5, 3, 3, NULL, '2020-06-29 18:00:38', '2020-06-29 18:00:38', NULL);
