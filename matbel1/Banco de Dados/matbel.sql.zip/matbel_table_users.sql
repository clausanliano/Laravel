
-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `opm_id` int(11) NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `opm_id`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Administrador', 'admin@admin.com', 53, '$2y$10$rGtfm2nor/9gQYQzgAyBuuYsM5G5FSrHAefdu/UaQFj23OTw/4.Xe', 'q77tBYfmGH99WjPLsZOYWdkTtIMkTXr5D9PMMA53RAkZAxMVXaqnZ1DOddCq', NULL, '2020-07-01 18:57:27'),
(4, 'Edinardo Gurgel Linhares', 'edinardolinhares@gmail.com', 13, '$2y$10$awzeGci9hhhP7gwHsFhSueFT7WJox0M/fCBTjZMevM7fT3jYLaqi6', 'qDUDvnJiKPtMCXK2vvhfyB1zr18KaXggM1uaXb1H7FzHnWqnK22BnFIH66gH', '2020-02-05 22:17:07', '2020-06-29 15:58:34'),
(7, 'Edinardo Gurgel Linhares', 'admin@admin.com2', 13, '$2y$10$ET/cYJ6VWQvsPMJ1EulV9.unr6o3HJEp4aYKKriJIAfbiy5v1fXTi', NULL, '2020-05-10 00:32:32', '2020-05-10 00:32:32'),
(9, 'Edinardo Gurgel Linhares', 'admin2@admin.com', 13, '$2y$10$dPG1bOR2PnudqGNjGCf.PuSpWc.YoIMSefLX6V8qwVKLvuc2yAUt6', 'X3pDiXupZncgEIBDzPugUsjbSbOtOGxRcufil8ADOzzYpkUci9HMPkgOkRZq', '2020-06-11 22:53:50', '2020-06-29 15:59:34');
