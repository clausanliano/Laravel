
-- --------------------------------------------------------

--
-- Estrutura da tabela `modelos_arma`
--

DROP TABLE IF EXISTS `modelos_arma`;
CREATE TABLE `modelos_arma` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comprimento_cano` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observacao` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `calibre_id` bigint(20) UNSIGNED NOT NULL,
  `tipo_arma_id` bigint(20) UNSIGNED NOT NULL,
  `fabricante_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `modelos_arma`
--

INSERT INTO `modelos_arma` (`id`, `nome`, `comprimento_cano`, `observacao`, `calibre_id`, `tipo_arma_id`, `fabricante_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 'PT100', '100', NULL, 4, 3, 1, '2020-05-04 04:50:34', '2020-05-04 04:50:34', NULL),
(3, 'MD5', '110', NULL, 5, 3, 3, '2020-06-11 21:29:05', '2020-07-04 00:49:24', NULL),
(4, 'T-4', '300', NULL, 5, 5, 1, '2020-07-04 00:50:30', '2020-07-04 00:50:30', NULL);
