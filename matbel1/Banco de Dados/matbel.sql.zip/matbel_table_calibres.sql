
-- --------------------------------------------------------

--
-- Estrutura da tabela `calibres`
--

DROP TABLE IF EXISTS `calibres`;
CREATE TABLE `calibres` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `calibres`
--

INSERT INTO `calibres` (`id`, `nome`, `created_at`, `updated_at`, `deleted_at`) VALUES
(4, '.40', '2020-05-04 04:49:10', '2020-06-11 22:12:13', NULL),
(5, '.357', '2020-06-11 22:12:23', '2020-07-04 00:42:46', NULL),
(6, '9mm', '2020-06-11 22:12:31', '2020-06-11 22:12:31', NULL),
(7, '.38', '2020-06-11 22:35:54', '2020-06-11 22:35:54', NULL),
(8, '12', '2020-06-11 22:39:53', '2020-06-11 22:39:53', NULL);
