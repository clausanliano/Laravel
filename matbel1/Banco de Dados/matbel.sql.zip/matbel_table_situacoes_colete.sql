
-- --------------------------------------------------------

--
-- Estrutura da tabela `situacoes_colete`
--

DROP TABLE IF EXISTS `situacoes_colete`;
CREATE TABLE `situacoes_colete` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `situacoes_colete`
--

INSERT INTO `situacoes_colete` (`id`, `nome`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'EM USO', '2020-05-02 02:56:29', '2020-05-02 02:56:29', NULL),
(2, 'EXTRAVIADO', '2020-05-02 02:56:51', '2020-05-02 02:56:51', NULL),
(3, 'DANIFICADO', '2020-05-02 02:57:08', '2020-05-02 02:57:08', NULL),
(4, 'JUSTIÇA', '2020-05-02 02:56:29', '2020-05-02 02:56:29', NULL),
(5, 'VENCIDO', '2020-05-02 02:56:51', '2020-05-02 02:56:51', NULL),
(6, 'CAUTELADO\r\n', '2020-05-02 02:57:08', '2020-05-02 02:57:08', NULL),
(7, 'ALTERADO', '2020-05-02 02:57:08', '2020-05-02 02:57:08', NULL),
(8, 'SEM USO', '2020-05-02 02:57:08', '2020-05-02 02:57:08', NULL);
