
-- --------------------------------------------------------

--
-- Estrutura da tabela `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'web', 'web', NULL, NULL),
(2, 'Listar Produtos', 'web', '2020-02-07 17:29:50', '2020-02-07 17:30:02'),
(7, 'Básica Material Bélico', 'web', '2020-02-10 18:11:02', '2020-02-10 18:11:02'),
(8, 'Administrador Material Bélico', 'web', '2020-02-11 16:59:50', '2020-02-11 16:59:50'),
(9, 'Administrador Pq Moto', 'web', '2020-02-11 17:10:26', '2020-02-11 17:20:38'),
(10, 'Administrador Ordem de Serviço', 'web', '2020-02-11 17:15:56', '2020-02-11 17:20:57'),
(11, 'Administrador Escolta', 'web', '2020-02-11 17:19:40', '2020-02-11 17:19:40'),
(12, 'Administrador Cadastros Pessoal e OPM', 'web', '2020-02-11 17:24:03', '2020-02-11 17:24:03');
