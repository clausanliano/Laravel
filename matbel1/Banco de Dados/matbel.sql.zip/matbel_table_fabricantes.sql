
-- --------------------------------------------------------

--
-- Estrutura da tabela `fabricantes`
--

DROP TABLE IF EXISTS `fabricantes`;
CREATE TABLE `fabricantes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `fabricantes`
--

INSERT INTO `fabricantes` (`id`, `nome`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'TAURUS', '2020-02-07 21:46:23', '2020-02-07 21:46:23', NULL),
(2, 'INBRA', '2020-05-03 16:57:42', '2020-05-03 16:57:42', NULL),
(3, 'IMBEL', '2020-06-11 21:28:30', '2020-06-11 22:10:49', NULL),
(4, 'ROSSI', '2020-06-11 22:37:17', '2020-06-11 22:37:26', NULL),
(9, 'STOPOWER', '2020-02-07 21:46:23', '2020-02-07 21:46:23', NULL),
(10, 'GLAGIO DO BRASIL', '2020-05-03 16:57:42', '2020-05-03 16:57:42', NULL),
(11, 'PROTECTA', '2020-06-11 21:28:30', '2020-06-11 22:10:49', NULL),
(12, 'CBC', '2020-06-11 22:37:17', '2020-06-11 22:37:26', NULL),
(13, 'INBRA-TEXTIL', '2020-06-11 21:28:30', '2020-06-11 22:10:49', NULL),
(14, 'RONTAM GOLD FLEX', '2020-06-11 22:37:17', '2020-06-11 22:37:26', NULL),
(15, 'BLINTEC', '2020-02-07 21:46:23', '2020-02-07 21:46:23', NULL),
(16, 'INBRALAND', '2020-05-03 16:57:42', '2020-05-03 16:57:42', NULL),
(17, 'INBRATERRESTRE', '2020-06-11 21:28:30', '2020-06-11 22:10:49', NULL),
(18, 'ILEGIVEL', '2020-06-11 22:37:17', '2020-06-11 22:37:26', NULL);
