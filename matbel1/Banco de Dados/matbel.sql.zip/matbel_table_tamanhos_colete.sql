
-- --------------------------------------------------------

--
-- Estrutura da tabela `tamanhos_colete`
--

DROP TABLE IF EXISTS `tamanhos_colete`;
CREATE TABLE `tamanhos_colete` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tamanhos_colete`
--

INSERT INTO `tamanhos_colete` (`id`, `nome`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'P', '2020-02-07 21:46:23', '2020-02-07 21:46:23', NULL),
(2, 'M', NULL, NULL, NULL),
(3, 'G', NULL, NULL, NULL),
(4, 'GG', NULL, NULL, NULL),
(5, '-', NULL, NULL, NULL);
