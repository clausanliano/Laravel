
-- --------------------------------------------------------

--
-- Estrutura da tabela `tipos_municao`
--

DROP TABLE IF EXISTS `tipos_municao`;
CREATE TABLE `tipos_municao` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tipos_municao`
--

INSERT INTO `tipos_municao` (`id`, `nome`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Treina', '2020-04-29 00:44:07', '2020-04-29 00:44:07', NULL),
(2, 'Recarregada', '2020-04-29 00:44:19', '2020-04-29 00:44:19', NULL),
(3, 'Operacional', '2020-04-29 00:44:39', '2020-04-29 00:44:39', NULL),
(4, 'Festim', '2020-06-11 22:50:12', '2020-06-11 22:50:12', NULL),
(5, 'Teste', '2020-06-11 22:51:15', '2020-06-11 22:51:15', NULL);
