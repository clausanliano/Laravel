
-- --------------------------------------------------------

--
-- Estrutura da tabela `cautelas`
--

DROP TABLE IF EXISTS `cautelas`;
CREATE TABLE `cautelas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `usuario` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dt_cautela` date NOT NULL,
  `dt_exclusao` date DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  `observacao` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cautela` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `opm_id` bigint(20) UNSIGNED NOT NULL,
  `policial_id` bigint(20) UNSIGNED NOT NULL,
  `arma_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `cautelas`
--

INSERT INTO `cautelas` (`id`, `usuario`, `dt_cautela`, `dt_exclusao`, `quantidade`, `observacao`, `cautela`, `opm_id`, `policial_id`, `arma_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(12, '5', '2020-06-22', NULL, 14, NULL, '1', 11, 5, 5, '2020-06-30 17:06:02', '2020-07-04 01:00:12', NULL),
(14, '4', '2020-07-09', NULL, 10, NULL, '1', 13, 6, 5, '2020-07-04 01:01:44', '2020-07-04 01:01:44', NULL);
