
-- --------------------------------------------------------

--
-- Estrutura da tabela `situacoes`
--

DROP TABLE IF EXISTS `situacoes`;
CREATE TABLE `situacoes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `situacoes`
--

INSERT INTO `situacoes` (`id`, `nome`, `created_at`, `updated_at`, `deleted_at`) VALUES
(4, 'Extraviada', '2020-05-04 04:49:30', '2020-06-11 22:12:57', NULL),
(5, 'Em Uso', '2020-06-11 22:38:55', '2020-06-11 22:38:55', NULL),
(6, 'Justiça', '2020-06-11 22:39:05', '2020-06-11 22:39:05', NULL),
(7, 'Cautelada', '2020-06-11 22:39:23', '2020-07-04 00:54:09', NULL);
