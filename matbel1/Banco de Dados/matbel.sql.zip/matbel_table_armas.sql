
-- --------------------------------------------------------

--
-- Estrutura da tabela `armas`
--

DROP TABLE IF EXISTS `armas`;
CREATE TABLE `armas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `numero_serie` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_tombo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `carregador` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacao` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modelo_arma_id` bigint(20) UNSIGNED NOT NULL,
  `situacao_id` bigint(20) DEFAULT NULL,
  `opm_id` bigint(20) UNSIGNED DEFAULT NULL,
  `subunidade` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `armas`
--

INSERT INTO `armas` (`id`, `numero_serie`, `numero_tombo`, `carregador`, `observacao`, `modelo_arma_id`, `situacao_id`, `opm_id`, `subunidade`, `created_at`, `updated_at`, `deleted_at`) VALUES
(5, '121212', '221212', '2', NULL, 2, 4, 13, 'Teste', '2020-06-11 18:56:36', '2020-07-04 00:38:23', NULL),
(10, '12345', '212333', '3', NULL, 2, 5, 13, 'Teste', '2020-07-01 19:03:51', '2020-07-01 19:08:20', NULL);
