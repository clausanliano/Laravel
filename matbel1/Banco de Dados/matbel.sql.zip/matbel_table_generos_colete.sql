
-- --------------------------------------------------------

--
-- Estrutura da tabela `generos_colete`
--

DROP TABLE IF EXISTS `generos_colete`;
CREATE TABLE `generos_colete` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `generos_colete`
--

INSERT INTO `generos_colete` (`id`, `nome`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Masculino', '2020-02-07 21:46:23', '2020-02-07 21:46:23', NULL),
(2, 'Feminino', '2020-02-07 21:46:23', '2020-02-07 21:46:23', NULL),
(3, 'Não Declarado', '2020-06-11 22:42:26', '2020-06-11 22:42:44', NULL);
